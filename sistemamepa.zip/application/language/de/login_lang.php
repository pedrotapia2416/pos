<?php 

$lang["login_gcaptcha"] = "";
$lang["login_go"] = "Start";
$lang["login_invalid_gcaptcha"] = "";
$lang["login_invalid_installation"] = "";
$lang["login_invalid_username_and_password"] = "Ungültiger Benutzername/Passwort";
$lang["login_login"] = "Login";
$lang["login_password"] = "Passwort";
$lang["login_username"] = "Benutzername";
