<?php 

$lang["login_gcaptcha"] = "";
$lang["login_go"] = "Verstuur";
$lang["login_invalid_gcaptcha"] = "";
$lang["login_invalid_installation"] = "";
$lang["login_invalid_username_and_password"] = "Ongeldige gebruiker/paswoord";
$lang["login_login"] = "Login";
$lang["login_password"] = "Paswoord";
$lang["login_username"] = "Gebruiker";
