<?php 

$lang["error_no_permission_module"] = "ທ່ານບໍ່ໄດ້ຮັບອະນຸຍາດໃຫ້ເຂົ້າເຖິງຂໍ້ມູນສ່ວນນີ້";
$lang["error_unknown"] = "ບໍ່ຮູ້";
