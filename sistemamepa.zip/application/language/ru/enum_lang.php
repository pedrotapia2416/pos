<?php 

$lang["enum_half_down"] = "Половина Вниз";
$lang["enum_half_even"] = "Половина Даже";
$lang["enum_half_five"] = "Половина на Пять";
$lang["enum_half_odd"] = "Половина Нечетного";
$lang["enum_half_up"] = "Половина, Вверх";
$lang["enum_round_down"] = "Oкруглять Вниз";
$lang["enum_round_up"] = "Oкруглять Вверх";
