<?php 

$lang["enum_half_down"] = "Mitad abajo";
$lang["enum_half_even"] = "Mitad par";
$lang["enum_half_five"] = "Mitad y cinco";
$lang["enum_half_odd"] = "Mitad impar";
$lang["enum_half_up"] = "Mitad arriba";
$lang["enum_round_down"] = "Redondeo abajo";
$lang["enum_round_up"] = "Redondeo arriba";
