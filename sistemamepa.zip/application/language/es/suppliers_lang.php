<?php 

$lang["suppliers_account_number"] = "Cuenta #";
$lang["suppliers_agency_name"] = "Nombre de la Agencia";
$lang["suppliers_cannot_be_deleted"] = "No se pudo borrar los productores seleccionados. Uno o más de los seleccionados tiene ventas.";
$lang["suppliers_company_name"] = "Nombre de la Compañía";
$lang["suppliers_company_name_required"] = "Nombre de la Compañía es requerido.";
$lang["suppliers_confirm_delete"] = "¿Seguro(a) de querer borrar los productores seleccionados?";
$lang["suppliers_confirm_restore"] = "Esta seguro de quere restaurar el(s) Productor(es) seleccionado(s)?";
$lang["suppliers_error_adding_updating"] = "Error agregando/actualizando productor.";
$lang["suppliers_new"] = "Nuevo Productor";
$lang["suppliers_none_selected"] = "No has seleccionado Productor para borrar.";
$lang["suppliers_one_or_multiple"] = "Productor(es)";
$lang["suppliers_successful_adding"] = "Has agregado el Productor satisfactoriamente";
$lang["suppliers_successful_deleted"] = "Has borrado satisfactoriamente a";
$lang["suppliers_successful_updating"] = "Has actualizado el Productor satisfactoriamente";
$lang["suppliers_supplier"] = "Productor";
$lang["suppliers_supplier_id"] = "Id";
$lang["suppliers_update"] = "Actualizar Productor";
